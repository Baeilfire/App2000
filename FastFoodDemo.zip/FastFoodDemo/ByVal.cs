﻿namespace FastFoodDemo
{
    internal class ByVal
    {
    }
}