﻿namespace FastFoodDemo
{
    internal class FirstCustomControl
    {
        public FirstCustomControl()
        {
        }
    }
}